from django.contrib import admin
from .models import Notifications


admin.site.register(Notifications)
