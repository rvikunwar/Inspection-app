from django.apps import AppConfig


class InspectionappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Inspectionapp'
    verbose_name = "Entity and members list"
