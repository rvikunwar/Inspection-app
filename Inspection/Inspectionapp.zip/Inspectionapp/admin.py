from django.contrib import admin
from .models import *

admin.site.register(Entity)
admin.site.register(TaskAssigned)
admin.site.register(Todo)
admin.site.register(Files)
admin.site.register(Areas)

